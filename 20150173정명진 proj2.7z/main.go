package main

import (
	"fmt"
	"time"
)

func main() {

	buffer := func() chan int {
		ch := make(chan int, 100)

		go func() {
			for i := 0; i < 100; i++ {
				ch <- i

			}

		}()

		return ch
	}

	consumer := buffer()
	producer := buffer()

	for i := 0; i < 200; i++ {
		select {
		case n := <-consumer:
			fmt.Println("Consumer: ", n)
			time.Sleep(50 * time.Millisecond)

		case n := <-producer:
			fmt.Println("Producer: ", n)
			time.Sleep(50 * time.Millisecond)
		}
	}
	close(consumer)
	close(producer)

}
